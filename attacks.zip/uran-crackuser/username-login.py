try:
  os.system('clear')
  print("Vui lòng chờ tool đang chạy......")
  txt=requests.get("https://pastebin.com/raw/yPnKCxjn").text
  os.system('clear')
  user=input("</> Username: ")
  inputpassword=input("</> Password: ")
except NameError:
  print("Hệ thống đang bị lỗi vui lòng chạy lại nhé")
  exit()
except:
  print("Hệ thống đang bị lỗi vui lòng chạy lại nhé")
  exit()
def login():
  os.system('clear')
  time2= json.loads(time)
  arraytime=time2["unixtime"]
  txt2 = json.loads(txt)
  try:
    arraytxt2=txt2[user]
    password = arraytxt2[0]
    daytxt = arraytxt2[1]
    print(daytxt)
    if password == inputpassword:
      print("Login thành công...")
      if arraytime <= daytxt:
        print("Kiểm tra thời gian chạy tool thành công...")
      else:
        print("User của bạn đã hết thời gian chạy tool")
        print("Liên hệ email: hackkid980@gmail.com")
    else:
      print("Sai Mật Khẩu Rồi!!!!!")
      print("Liên hệ email: hackkid980@gmail.com")
      sys.exit(1)
      exit()
  except NameError:
    print("Không có user này nhé")
    print("Liên hệ email: hackkid980@gmail.com")
    exit()
  except:
    print("Không có user này nhé")
    print("Liên hệ email: hackkid980@gmail.com")
    exit()
login()
